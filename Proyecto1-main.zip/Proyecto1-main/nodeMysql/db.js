// desestructuración {}
import {createPool} from 'mysql2/promise'; 

export const conn = createPool({
    host: 'localhost',
    user: 'root',
    password: 'vj8By6z.U:f2.Su',
    port: 3306,
    database: 'Proyecto'
});

