// index.routes.js
import { Router } from 'express';
import { showCatalogo,Tokenauth} from '../controllers/users.controllers.js';

const router = Router();

router.get('/catalogo',Tokenauth, showCatalogo);

export default router;
